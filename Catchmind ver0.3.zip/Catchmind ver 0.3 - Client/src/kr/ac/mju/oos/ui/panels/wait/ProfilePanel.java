package kr.ac.mju.oos.ui.panels.wait;
//���� ����
import javax.swing.JPanel;

public class ProfilePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public ProfilePanel() {
		// TODO Auto-generated constructor stub
		init();
	}

	public void init() {

	}
}

package kr.ac.mju.oos.uility;

public interface Tool {

}

package kr.ac.mju.oos.ui.tabs;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class ClientInfTab extends JPanel {

	private static final long serialVersionUID = 1L;

	public ClientInfTab() {

	}

	public void init() {
		// TODO Auto-generated method stub
		this.add(new JLabel("ClientInformationTab"));
	}
}

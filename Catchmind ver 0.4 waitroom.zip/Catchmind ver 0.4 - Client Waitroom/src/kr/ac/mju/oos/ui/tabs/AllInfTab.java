package kr.ac.mju.oos.ui.tabs;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class AllInfTab extends JPanel {

	private static final long serialVersionUID = 1L;

	public AllInfTab() {
		// TODO Auto-generated constructor stub
	}

	public void init() {
		// TODO Auto-generated method stub
		this.add(new JLabel("AllInformationTab"));
	}

}

package kr.ac.mju.oos.model.dto;

public class UserDataBean {

}

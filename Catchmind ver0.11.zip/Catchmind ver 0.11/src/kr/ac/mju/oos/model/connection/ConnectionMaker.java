package kr.ac.mju.oos.model.connection;

public class ConnectionMaker {

}

package kr.ac.mju.oos.model.dao;

public class UserManager {

}

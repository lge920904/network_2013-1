package kr.ac.mju.oos.ui.panels.wait;
//���� ����
import javax.swing.JPanel;

public class ChatPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public ChatPanel() {
		// TODO Auto-generated constructor stub
		init();
	}

	public void init() {

	}
}

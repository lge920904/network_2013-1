package kr.ac.mju.oos.controller;

import kr.ac.mju.oos.ui.panels.wait.RoomListPanel;
import kr.ac.mju.oos.uility.Room;

public class WaitController extends Controller {
	private RoomListPanel roomListPanel;
	private Room createRoom;

	@Override
	public boolean sendData(String sendString) {
		// TODO Auto-generated method stub
		// if (initFlag) {
		if (this.frontController.getWaitController() == null) {
			frontController.setWaitController(this);
		}
		frontController.sendData("Wait:" + sendString);
		return true;
		// }
		// return false;
	}

	public WaitController(RoomListPanel roomPanel) {
		// TODO Auto-generated constructor stub
		this.roomListPanel = roomPanel;
		this.frontController = FrontController.getInstance();
		// this.frontController = FrontController.getInstance();
	}

	public void setRoomPanel(RoomListPanel roomPanel) {
		this.roomListPanel = roomPanel;
	}

	public void sendJoinRoom(int roomNumber) {
		sendData(new String("Join:" + roomNumber));
	}

	public void sendCreateRoom(String[] createRoom, Room room) {
		this.createRoom = room;
		System.out.println("sendCreateRoom");
		System.out.println("CREATE:" + createRoom[0] + " " + createRoom[1]
				+ " " + createRoom[2] + " " + createRoom[3] + " "
				+ createRoom[4]);
		sendData("CREATE:" + createRoom[0] + " " + createRoom[1] + " "
				+ createRoom[2] + " " + createRoom[3] + " " + createRoom[4]);
	}

	public void sendExitRoom(String[] exitRoom) {

	}

	public void sendMatchingRoom(String[] matchingRoom) {

	}

	public void setRoomNumber(int serialNumber) {
		if (createRoom != null) {
			createRoom.setRoomNumber(serialNumber);
		}
	}
}

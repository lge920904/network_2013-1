package kr.ac.mju.oos.tool;

public interface Tool {

}

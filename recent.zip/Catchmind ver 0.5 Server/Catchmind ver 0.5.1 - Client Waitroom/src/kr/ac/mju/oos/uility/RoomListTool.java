package kr.ac.mju.oos.uility;

import java.util.ArrayList;

import javax.swing.JPanel;

import kr.ac.mju.oos.controller.WaitController;
import kr.ac.mju.oos.ui.panels.wait.RoomListPanel;

public class RoomListTool implements Tool {

	private RoomListPanel roomListPanel;
	private GameModeChanger gameModeChanger;
	private ArrayList<JPanel> roomList;
	private Room room;
	private int totalRoomNum;
	private WaitController waitController;

	public RoomListTool(GameModeChanger gameModeChanger) {
		this.roomListPanel = roomListPanel;
		totalRoomNum = 0;
		roomList = new ArrayList<JPanel>();
		this.waitController = new WaitController(this.roomListPanel);
		System.out.println("WaitController");
		this.gameModeChanger = gameModeChanger;
	}

	public void createRoom(String roomName, String gameMode, String itemMode,
			Object secret, Object person, String roomPassword) {
		room = new Room();
		room.setRoomInfo(roomName, gameMode, itemMode,
				secret, person,roomPassword);
		if(room.createRoom()){
		roomList.add(room);
		totalRoomNum++;
		roomListPanel.addRoom(room, totalRoomNum);
		
		String[] infs = new String[5];
		infs[0] = roomName;
		infs[1] = gameMode;
		infs[2] = itemMode;
		infs[3] = secret.toString();
		infs[4] = person.toString();

		waitController.sendCreateRoom(infs, room);
		//gameModeChanger.joinGameRoom();
		}
	}
	
	public void selectedRoom(Room selectedRoom){
		gameModeChanger.joinGameRoom(selectedRoom);
	}
	public void showAllRoom() {
		for (int i = 0; i < totalRoomNum; i++) {
			roomList.get(i).setVisible(true);
		}
	}

	public void showItemRoom() {
		for (int i = 0; i < totalRoomNum; i++) {
			if (roomList.get(i).getComponent(2).getName().equals("아이템전")) {
				roomList.get(i).setVisible(true);
			} else {
				roomList.get(i).setVisible(false);
			}

		}
	}

	public void showNoItemRoom() {
		for (int i = 0; i < totalRoomNum; i++) {
			if (roomList.get(i).getComponent(2).getName().equals("노템전")) {
				roomList.get(i).setVisible(true);
			} else {
				roomList.get(i).setVisible(false);
			}
		}
	}
}

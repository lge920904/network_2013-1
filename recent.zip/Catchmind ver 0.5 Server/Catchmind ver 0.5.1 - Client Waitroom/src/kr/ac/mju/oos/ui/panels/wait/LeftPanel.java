package kr.ac.mju.oos.ui.panels.wait;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;

import kr.ac.mju.oos.constants.Constants;
import kr.ac.mju.oos.uility.GameModeChanger;
import kr.ac.mju.oos.uility.RoomListTool;

public class LeftPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private MenuPanel menuPanel;
	private RoomListPanel roomListPanel;
	private RoomListTool roomListTool;

	public LeftPanel() {
		roomListPanel = new RoomListPanel();
		menuPanel = new MenuPanel();
	}

	public void init(GameModeChanger gameModeChanger) {
		this.setPreferredSize(new Dimension(Constants.PANELS_LEFT_WIDTH,
				Constants.FRAMES_MAIN_HEIGHT));
		this.setLayout(new BorderLayout());

		this.add(menuPanel, BorderLayout.NORTH);
		this.add(roomListPanel, BorderLayout.CENTER);

		roomListTool = new RoomListTool(gameModeChanger);
		menuPanel.init(roomListTool,gameModeChanger);
		roomListPanel.init(roomListTool,gameModeChanger);
	}
}

package kr.ac.mju.oos.wait;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class StreamThread implements Runnable {
	private MainServer waitServer;
	private Socket socket;
	private ObjectOutputStream objectOutputStream;
	private BufferedReader reader;

	public StreamThread(MainServer waitServer, Socket socket) {
		// TODO Auto-generated constructor stub
		try {
			System.out.println("접속시도");
			this.waitServer = waitServer;
			this.socket = socket;
			reader = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
			this.objectOutputStream = new ObjectOutputStream(
					socket.getOutputStream());
			this.objectOutputStream.flush();
			System.out.println(objectOutputStream);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("wait Stream Thread Error");
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		String msg = "";
		try {
			while ((msg = reader.readLine()) != null) {
				// System.out.println("RoomHandler " + msg);
				String[] tokens = msg.split(":");
				String[] recMsg = tokens[1].split(" ");

				if (tokens[0].equals("JOIN")) {
					waitServer.joinRoom(recMsg);
				} else if (tokens[0].equals("CREATE")) {
					System.out.println("--------Wait Server------");
					System.out.println("Socket Channel : "
							+ socket.getChannel());
					System.out.println("Socket Port : " + socket.getPort());
					System.out.println("Socket InetAddress : "
							+ socket.getInetAddress());
					waitServer.createRoom(recMsg);
					objectOutputStream.writeObject("Wait:CREATE:roomNumber:"
							+ String.valueOf(waitServer.getSerialNumber()));
					objectOutputStream.flush();

				} else if (tokens[0].equals("EXIT")) {
					waitServer.exitRoom(recMsg);
				} else if (tokens[0].equals("MATCHING")) {
					waitServer.matchingRoom(recMsg);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Stream Thread Error");
		}
	}
}